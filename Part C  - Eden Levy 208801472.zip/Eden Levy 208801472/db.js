const config = require("./db.config");
const mysql = require("mysql");

const conn = mysql.createConnection(config);

conn.connect();

init = () => {
    conn.query(
        `CREATE DATABASE IF NOT EXISTS web;`,
        function (err, data, fields) {
            if (err) {
                throw new Error(err.message);
            } else {
                console.log({
                    status: "success",
                    message: "database web created!",
                });
            }
        }
    );

    conn.query(
        `CREATE TABLE IF NOT EXISTS web.users (
            id INT NOT NULL AUTO_INCREMENT,
            username VARCHAR(25) NOT NULL ,
            password VARCHAR(25) NOT NULL ,
            email VARCHAR(50) NOT NULL ,
            age INT NOT NULL ,
            phone VARCHAR(25) NOT NULL ,
            image TEXT NOT NULL ,
            PRIMARY KEY (id)
        );`,
        function (err, data, fields) {
            if (err) {
                throw new Error(err.message);
            } else {
                console.log({
                    status: "success",
                    message: "users table created!",
                });
            }
        }
    );

    conn.query(
        `CREATE TABLE IF NOT EXISTS web.resturants (
            id INT NOT NULL AUTO_INCREMENT,
            name VARCHAR(25) NOT NULL ,
            typeOfKitchen VARCHAR(25) NOT NULL ,
            location VARCHAR(50) NOT NULL ,
            PRIMARY KEY (id)
        );`,
        function (err, data, fields) {
            if (err) {
                throw new Error(err.message);
            } else {
                console.log({
                    status: "success",
                    message: "resturants table created!",
                });
            }
        }
    );

    conn.query(
        `CREATE TABLE IF NOT EXISTS web.reviews (
            id INT NOT NULL AUTO_INCREMENT,
            resturant_id INT NOT NULL ,
            fullname VARCHAR(25) NOT NULL ,
            rating INT NOT NULL ,
            review TEXT NULL ,
            PRIMARY KEY (id)
        );`,
        function (err, data, fields) {
            if (err) {
                throw new Error(err.message);
            } else {
                console.log({
                    status: "success",
                    message: "reviews table created!",
                });
            }
        }
    );

    conn.query(
        `SELECT COUNT(*) as count FROM web.users`,
        function (err, data, fields) {
            if (err) {
                throw new Error(err.message);
            } else {
                // create user for not exsits already
                results = JSON.parse(JSON.stringify(data));
                if (results[0].count === 0) {
                    for (let i = 1; i <= 5; i++) {
                        // create 5 starter users
                        conn.query(
                            `INSERT INTO web.users (id, username, password, email, age, phone, image)
                            VALUES (${i}, 'user${i}', '123456', 'user${i}@gmail.com', ${
                                20 + i
                            }, '054100000${i}', 'images/profile.jpeg')`,
                            function (err, data, fields) {
                                if (err) {
                                    throw new Error(err.message);
                                } else {
                                    console.log({
                                        status: "success",
                                        message: `user user${i} created!`,
                                    });
                                }
                            }
                        );
                    }

                    const resturants = [
                        {
                            name: "Kampai",
                            typeOfKitchen: "Sushi",
                            location: "Beer Sheva",
                        },
                        {
                            name: "Vivino",
                            typeOfKitchen: "Italian",
                            location: "Haifa",
                        },
                        {
                            name: "De Yaffa",
                            typeOfKitchen: "Arabic",
                            location: "Tel Aviv",
                        },
                        {
                            name: "SADAFA",
                            typeOfKitchen: "Arabic",
                            location: "Beer Sheva",
                        },
                        {
                            name: "Claro",
                            typeOfKitchen: "Mediterranean",
                            location: "Tel Aviv",
                        },
                        {
                            name: "Menta Ray",
                            typeOfKitchen: "Mediterranean",
                            location: "Tel Aviv",
                        },
                        {
                            name: "Golden Coral",
                            typeOfKitchen: "Mediterranean",
                            location: "Haifa",
                        },
                        {
                            name: "Cramim",
                            typeOfKitchen: "Fusion",
                            location: "Modiin",
                        },
                        {
                            name: "Nafis",
                            typeOfKitchen: "Israeli",
                            location: "Holon",
                        },
                        {
                            name: "Mina Tomey",
                            typeOfKitchen: "Asian",
                            location: "Tel Aviv",
                        },
                        {
                            name: "Zozobra",
                            typeOfKitchen: "Asian",
                            location: "Tel Aviv",
                        },
                        {
                            name: "SOHO",
                            typeOfKitchen: "Asian",
                            location: "Rishon Lezion",
                        },
                        {
                            name: "Thai House",
                            typeOfKitchen: "Thai",
                            location: "Tel Aviv",
                        },
                        {
                            name: "Nam",
                            typeOfKitchen: "Thai",
                            location: "Tel Aviv",
                        },
                        {
                            name: "Nini Hatchi",
                            typeOfKitchen: "Thai",
                            location: "Tel Aviv",
                        },
                        {
                            name: "Taizu",
                            typeOfKitchen: "Asian",
                            location: "Tel Aviv",
                        },
                        {
                            name: "Anastasia",
                            typeOfKitchen: "Vegetarian",
                            location: "Tel Aviv",
                        },
                        {
                            name: "Opa",
                            typeOfKitchen: "Vegan",
                            location: "Tel Aviv",
                        },
                    ];

                    for (let i = 0; i < resturants.length; i++) {
                        // create resturants
                        conn.query(
                            `INSERT INTO web.resturants (id, name, typeOfKitchen, location)
                        VALUES (${i + 1}, '${resturants[i].name}', '${resturants[i].typeOfKitchen}', '${resturants[i].location}')`,
                            function (err, data, fields) {
                                if (err) {
                                    throw new Error(err.message);
                                } else {
                                    console.log({
                                        status: "success",
                                        message: `resturant ${resturants[i].name} created!`,
                                    });
                                }
                            }
                        );
                    }

                    for (let i = 0; i < resturants.length; i++) {
                        // create resturants
                        conn.query(
                            `INSERT INTO web.reviews(id, resturant_id, fullname, rating, review) VALUES (${i + 1},${i + 1},'Yoav Gilboa',${randomIntFromInterval(1, 5)},'')`,
                            function (err, data, fields) {
                                if (err) {
                                    throw new Error(err.message);
                                } else {
                                    console.log({
                                        status: "success",
                                        message: `review for resturant ${resturants[i].name} created!`,
                                    });
                                }
                            }
                        );
                    }
                }
            }
        }
    );
};

function randomIntFromInterval(min, max) {
    // min and max included
    return Math.floor(Math.random() * (max - min + 1) + min);
}

module.exports = { conn, init };
