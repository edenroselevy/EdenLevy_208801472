if (sessionStorage.getItem('LOGGED_IN_USER')) {
    const user = JSON.parse(sessionStorage.getItem("LOGGED_IN_USER"));
    const profileElement = document.getElementById('profile');
    profileElement.innerHTML = `
        <p class="profile">
            <img src="${user.image}" width="30">
            Hello ${user.username}
            <strong class="profile-logout" onclick="logout()">Logout</strong>
        </p>
    `;
}

function logout() {
    sessionStorage.clear();
    window.location = 'index.html';
}