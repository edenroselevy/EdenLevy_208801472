const SERVER_URL = "http://localhost:3000/api";

function doLogin(event) {
    event.preventDefault();
    if (validForm()) {
    fetch(`${SERVER_URL}/signIn`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
            email: document.querySelector("#username").value,
            password: document.querySelector("#password").value,
        }),
    })
        .then((response) => response.json())
        .then((response) => {
            if (response.data?.length > 0) {
                const user = response.data[0];
                sessionStorage.setItem("LOGGED_IN_USER", JSON.stringify(user));
                window.location = "index.html";
            } else {
                alert("No user was found for the given email & password!");
            }
        })
        .catch((e) => {
            console.log(e);
            alert("A server error occurred");
        });
    }
}

function validForm() {
    const usernameElem = document.querySelector("#username");
    const passwordElem = document.querySelector("#password");

    if (!usernameElem.value) {
        usernameElem.classList.add("invalid");
        alert("Username is required");
        return false;
    } else if (!passwordElem.value) {
        passwordElem.classList.add("invalid");
        alert("Password is required");
        return false;
    }

    return true;
}