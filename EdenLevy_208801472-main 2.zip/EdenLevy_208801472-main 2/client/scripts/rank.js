const SERVER_URL = "http://localhost:3000/api";
const optionsElem = document.querySelector(".resturant-options");
if (optionsElem) {
    fetch(`${SERVER_URL}/resturants`, {
        method: "GET",
        headers: { "Content-Type": "application/json" },
    })
        .then((response) => response.json())
        .then((response) => {
            if (response.data?.length > 0) {
                console.log(response.data);
                const resturants = response.data.sort((a, b) =>
                    a.name.localeCompare(b.name)
                );
                for (let i = 0; i < resturants?.length; i++) {
                    const resturant = resturants[i];
                    optionsElem.innerHTML += `
                        <option value="${resturant.id}">${resturant.name}</option>    
                    `;
                }
            } else {
                alert("No resturants was found");
            }
        })
        .catch((e) => {
            console.log(e);
            alert("A server error occurred");
        });
}

function mySubmitFunction(e) {
    e.preventDefault();
    if (validForm()) {
        const fullnameElem = document.querySelector("#fullname");
        const resturantElem = document.querySelector("#resturant");
        const rateElem = document.querySelector("#rate");
        const reviewElem = document.querySelector("#review");

        fetch(`${SERVER_URL}/reviews`, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                fullname: fullnameElem.value,
                resturant_id: resturantElem.value,
                rating: +rateElem.value.slice(0, 1),
                review: reviewElem.value,
            }),
        })
            .then((response) => response.json())
            .then((response) => {
                if (response.status === "success") {
                    window.location = "thanku.html";
                } else {
                    alert("Error while creating new review!");
                }
            })
            .catch((e) => {
                console.log(e);
                alert("A server error occurred");
            });
    }
    return false;
}

function validForm() {
    const fullnameElem = document.querySelector("#fullname");
    const resturantElem = document.querySelector("#resturant");
    const rateElem = document.querySelector("#rate");
    const reviewElem = document.querySelector("#review");

    if (!fullnameElem.value) {
        fullnameElem.classList.add("invalid");
        alert("Fullname is required");
        return false;
    }
    fullnameElem.classList.remove("invalid");

    if (!resturantElem.value) {
        resturantElem.classList.add("invalid");
        alert("Resturant is required");
        return false;
    }
    resturantElem.classList.remove("invalid");

    if (!rateElem.value) {
        rateElem.classList.add("invalid");
        alert("You must rate your experience");
        return false;
    }
    rateElem.classList.remove("invalid");

    if (!reviewElem.value) {
        reviewElem.classList.add("invalid");
        alert("Review is required");
        return false;
    }
    reviewElem.classList.remove("invalid");

    return true;
}
