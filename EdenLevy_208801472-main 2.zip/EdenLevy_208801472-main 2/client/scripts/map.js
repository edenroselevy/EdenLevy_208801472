async function initMap() {
    const apiKey = "AIzaSyAyk6v-3Lqx7qfcxUNpH6Cwflik_ktbwSo";
    const loader = new google.maps.plugins.loader.Loader({ apiKey });
    const googleLoader = await loader.load();
    const geocoder = new google.maps.Geocoder();

    var resturants;
    var center = { lat: 32.0718747, lng: 34.7849947 };
    var map = new google.maps.Map(document.getElementById("map"), {
        zoom: 8,
        center: center,
    });

    if (sessionStorage.getItem("RESTURANTS")) {
        resturants = JSON.parse(sessionStorage.getItem("RESTURANTS"));
    }

    const { maps } = googleLoader;

    for (let i = 0; i < resturants?.length; i++) {
        geocoder.geocode(
            { address: resturants[i].location },
            function (results, status) {
                if (status === "OK") {
                    var data = `<strong>${resturants[i].name}</strong><span>${results[0].formatted_address}</span>`;
                    var infowindow = new google.maps.InfoWindow({
                        content: data,
                    });
                    var marker = new google.maps.Marker({
                        map,
                        animation: maps.Animation.DROP,
                        position: results[0].geometry.location,
                        icon: {
                            url: "/images/pin.png",
                        },
                        title: "",
                    });
                    google.maps.event.addListener(marker, "click", function () {
                        infowindow.open(map, marker);
                    });
                } else {
                    console.log(
                        "Geocode was not successful for the following reason: " +
                            status
                    );
                }
            }
        );
    }
}

window.initMap = initMap;