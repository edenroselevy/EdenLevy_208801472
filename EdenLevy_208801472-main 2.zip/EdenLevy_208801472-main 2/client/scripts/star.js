const SERVER_URL = "http://localhost:3000/api";

fetch(`${SERVER_URL}/reviews`, {
    method: "GET",
    headers: { "Content-Type": "application/json" }
})
    .then((response) => response.json())
    .then((response) => {
        if (response.data?.length) {
            const tbody = document.getElementById("tbody");
            for (let i = 0; i < response.data?.length; i++) {
                const review = response.data[i];
                tbody.innerHTML += `
                    <tr class="border_bottom">
                        <td>${review.fullname}</td>
                        <td>${review.name}</td>
                        <td>${review.location}</td>
                        <td>${review.rating}</td>
                        <td>${review.review}</td>
                    </tr>
                `;
            }
        } else {
            alert("No reviews found");
        }
    })
    .catch((e) => {
        console.log(e);
        alert("A server error occurred");
    });
