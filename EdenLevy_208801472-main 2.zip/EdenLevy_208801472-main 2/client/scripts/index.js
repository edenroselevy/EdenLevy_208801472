const SERVER_URL = "http://localhost:3000/api";

function search(event) {
    event.preventDefault();
    if (validForm()) {
        const nameElem = document.querySelector("#Name");
        const typeOfKitchenElem = document.querySelector("#TypeOfKitchen");
        const locationElem = document.querySelector("#Location");
        const minRating = document.querySelector("#minRating");
        const minReviews = document.querySelector("#minReviews");
        
        fetch(
            `${SERVER_URL}/resturants?name=${nameElem.value}&typeOfKitchen=${typeOfKitchenElem.value}&location=${locationElem.value}&minRating=${minRating.value}&minReviews=${minReviews.value}`,
            {
                method: "GET",
                headers: { "Content-Type": "application/json" },
            }
        )
            .then((response) => response.json())
            .then((response) => {
                if (response.data?.length > 0) {
                    console.log(response.data);
                    sessionStorage.setItem(
                        "RESTURANTS",
                        JSON.stringify(response.data)
                    );
                    window.location = "map.html";
                } else {
                    alert("No resturants was found for the given search");
                }
            })
            .catch((e) => {
                console.log(e);
                alert("A server error occurred");
            });
    }
}

function validForm() {
    const nameElem = document.querySelector("#Name");
    const typeOfKitchenElem = document.querySelector("#TypeOfKitchen");
    const locationElem = document.querySelector("#Location");

    if (!nameElem.value && !typeOfKitchenElem.value && !locationElem.value) {
        alert("You must choose at least one filter");
        return false;
    }

    return true;
}
