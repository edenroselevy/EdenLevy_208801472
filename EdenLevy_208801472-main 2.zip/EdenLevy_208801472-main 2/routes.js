const express = require("express");
const controllers = require("./controllers");
const router = express.Router();

router.route("/api/signIn").post(controllers.signIn);
router.route("/api/signUp").post(controllers.signUp);
router.route("/api/reviews").get(controllers.selectReviews).post(controllers.createReview);
router.route("/api/resturants").get(controllers.searchResturants).post(controllers.createResturant);
router.route("/api/resturants/:id").get(controllers.selectResturant).put(controllers.updateResturant).delete(controllers.deleteResturant);

module.exports = router;