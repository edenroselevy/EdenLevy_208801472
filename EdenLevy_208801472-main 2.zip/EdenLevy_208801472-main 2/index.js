const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();
const routes = require("./routes");

app.use(cors());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(routes);

app.use(express.static(__dirname + "/client/views"));
app.use("/views", express.static(__dirname + "/client/views"));
app.use("/scripts", express.static(__dirname + "/client/scripts"));
app.use("/images", express.static(__dirname + "/client/images"));

const PORT = 3000;

app.listen(PORT, () => {
    console.log(`server running on port ${PORT}`);
});

const db = require('./db');
db.init();