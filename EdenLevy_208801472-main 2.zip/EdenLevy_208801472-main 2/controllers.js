const { conn } = require("./db");

exports.signIn = (req, res) => {
    const { email, password } = req.body;
    conn.query("SELECT * FROM `web`.`users` WHERE `email` = '" + email + "' AND `password` = '" + password + "' LIMIT 1",
    function (err, data, fields) {
        if (err) {
            res.status(500).json({ error: err.message });
        } else {
            res.status(200).json({
                data,
                status: "success",
                length: data?.length,
            });
        }
    });
};

exports.signUp = (req, res) => {
    if (!req.body) {
        res.status(404).json({ error: "No form data found" });
    } else {
        conn.query(
            `INSERT INTO \`web\`.\`users\`(\`username\`, \`password\`, \`email\`, \`age\`, \`phone\`, \`image\`) 
            VALUES ('${req.body.username}', '${req.body.password}', '${req.body.email}', '${req.body.age}', '${req.body.phone}', '${req.body.image}')`,
            function (err, mysqlres) {
                if (err) {
                    res.status(500).json({ error: err.message });
                } else {
                    res.status(201).json({
                        status: "success",
                        message: "user created!",
                    });
                }
            }
        );
    }
};

exports.searchResturants = async (req, res) => {
    const name = req.query["name"];
    const typeOfKitchen = req.query["typeOfKitchen"];
    const location = req.query["location"];
    const minRating = req.query["minRating"];
    const minReviews = req.query["minReviews"];

    const sql = `
        SELECT * FROM web.resturants 
        WHERE name LIKE '%${name ?? ''}%' AND typeOfKitchen LIKE '%${typeOfKitchen ?? ''}%' AND location LIKE '%${location ?? ''}%'
    `;

    conn.query(sql,
        function (err, data, fields) {
            if (err) {
                console.log(err);
                res.status(500).json({ error: err.message });
            }
            else if (minRating || minReviews) {
                let sql;
                let matches = [];
                const response = JSON.parse(JSON.stringify(data));

                for (let resturant of response) {

                    if (minRating && !minReviews) {
                        sql = `SELECT AVG(rating) as avg FROM web.reviews WHERE resturant_id = ${resturant.id}`;

                        conn.query(sql, function (err, data, fields) {
                            if (err) {
                                console.log(err);
                            }
                            else {
                                const response = JSON.parse(JSON.stringify(data));
                                console.log(response[0]);
                                if (+response[0].avg >= +minRating) {
                                    matches.push(resturant);
                                }
                            }
                        });
                    }
                    else if (!minRating && minReviews) {
                        sql = `SELECT COUNT(*) as count FROM web.reviews WHERE resturant_id = ${resturant.id}`;
                        
                        conn.query(sql, function (err, data, fields) {
                            if (err) {
                                console.log(err);
                            } else {
                                const response = JSON.parse(
                                    JSON.stringify(data)
                                );
                                console.log(response[0]);
                                if (+response[0].count >= +minReviews) {
                                    matches.push(resturant);
                                }
                            }
                        });
                    }
                    else if (minRating && minReviews) {
                        sql = `SELECT AVG(rating) as avg, COUNT(*) as count FROM web.reviews WHERE resturant_id = ${resturant.id}`;

                        conn.query(sql, function (err, data, fields) {
                            if (err) {
                                console.log(err);
                            } else {
                                const response = JSON.parse(
                                    JSON.stringify(data)
                                );
                                console.log(response[0]);
                                if (
                                    +response[0].avg >= +minRating &&
                                    +response[0].count >= +minReviews
                                ) {
                                    matches.push(resturant);
                                }
                            }
                        });
                    }
                }

                console.log({
                    data: matches,
                    status: "success",
                    length: matches?.length,
                });

                res.status(200).json({
                    data: matches,
                    status: "success",
                    length: matches?.length,
                });
            }
            else {
                console.log({
                    data,
                    status: "success",
                    length: data?.length,
                });

                res.status(200).json({
                    data,
                    status: "success",
                    length: data?.length,
                });
            }
        }
    );
};

exports.selectResturant = (req, res, next) => {
    if (!req.params.id) {
        res.status(404).json({ error: "No id found" });
    }
    else {
        conn.query(
            "SELECT * FROM `web`.`resturants` WHERE `id` = '" + req.params.id + "'",
            function (err, data, fields) {
                if (err) {
                    res.status(500).json({ error: err.message });
                } else {
                    res.status(200).json({
                        data,
                        status: "success",
                        length: data?.length,
                    });
                }
            }
        );
    }
};

exports.selectReviews = (req, res, next) => {
    conn.query("SELECT rev.*, res.* FROM web.reviews as rev JOIN web.resturants as res on res.id = rev.resturant_id",
        function (err, data, fields) {
            if (err) {
                res.status(500).json({ error: err.message });
            } else {
                res.status(200).json({
                    data,
                    status: "success",
                    length: data?.length,
                });
            }
        }
    );
};

exports.createReview = (req, res) => {
    if (!req.body) {
        res.status(404).json({ error: "No form data found" });
    } else {
        conn.query(
            `INSERT INTO \`web\`.\`reviews\`(\`resturant_id\`,\`fullname\`, \`rating\`, \`review\`) 
            VALUES (${req.body.resturant_id},'${req.body.fullname}', ${req.body.rating}, '${req.body.review}')`,
            function (err, mysqlres) {
                if (err) {
                    res.status(500).json({ error: err.message });
                } else {
                    res.status(201).json({
                        status: "success",
                        message: "review created!",
                    });
                }
            }
        );
    }
};

exports.createResturant = (req, res) => {
    if (!req.body) {
        res.status(404).json({ error: "No form data found" });
    } else {
        conn.query(
            `INSERT INTO \`web\`.\`resturants\`(\`name\`,\`typeOfKitchen\`, \`location\`) 
            VALUES ('${req.body.name}','${req.body.typeOfKitchen}', '${req.body.location}')`,
            function (err, mysqlres) {
                if (err) {
                    res.status(500).json({ error: err.message });
                } else {
                    res.status(201).json({
                        status: "success",
                        message: "resturant created!",
                    });
                }
            }
        );
    }
};

exports.updateResturant = (req, res, next) => {
    if (!req.params.id) {
        res.status(404).json({ error: "No id found" });
    } else {
        conn.query(
            `UPDATE \`web\`.\`resturants\` SET \`name\`='${req.body.name}',\`typeOfKitchen\`='${req.body.typeOfKitchen}',\`location\`='${req.body.location}' WHERE \`id\`='${req.params.id}'`,
            function (err, data, fields) {
                if (err) {
                    res.status(500).json({ error: err.message });
                } else {
                    res.status(201).json(req.body);
                }
            }
        );
    }
};

exports.deleteResturant = (req, res, next) => {
    if (!req.params.id) {
        res.status(404).json({ error: "No id found" });
    } else {
        conn.query(
            "DELETE FROM `web`.`resturants` WHERE `id`='" + req.params.id + "'",
            [req.params.id],
            function (err, fields) {
                if (err) {
                    res.status(500).json({ error: err.message });
                } else {
                    res.status(201).json({
                        status: "success",
                        message: "resturant deleted!",
                    });
                }
            }
        );
    }
};